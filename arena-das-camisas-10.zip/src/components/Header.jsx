import React from "react";

export default function Header({ cartCount }) {
  return (
    <header className="header">
      <h2>Arena das Camisas 10</h2>
      <span>Carrinho ({cartCount})</span>
    </header>
  );
}