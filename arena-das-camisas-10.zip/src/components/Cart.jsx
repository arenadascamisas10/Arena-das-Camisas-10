import React from "react";

export default function Cart({ cart, removeFromCart }) {
  return (
    <aside className="cart">
      <h3>Carrinho</h3>
      {cart.length === 0 && <p>Vazio</p>}
      <ul>
        {cart.map((item, i) => (
          <li key={i}>
            {item.name} - R$ {item.price.toFixed(2)}
            <button onClick={() => removeFromCart(i)}>Remover</button>
          </li>
        ))}
      </ul>
      {cart.length > 0 && (
        <p>
          Total: R$ {cart.reduce((acc, p) => acc + p.price, 0).toFixed(2)}
        </p>
      )}
    </aside>
  );
}