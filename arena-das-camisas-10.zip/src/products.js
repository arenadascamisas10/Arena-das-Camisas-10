export default [
  {
    name: "Camisa Flamengo 2025",
    price: 249.9,
    image: "https://via.placeholder.com/200x200.png?text=Flamengo",
  },
  {
    name: "Camisa Corinthians 2025",
    price: 239.9,
    image: "https://via.placeholder.com/200x200.png?text=Corinthians",
  },
  {
    name: "Camisa São Paulo 2025",
    price: 229.9,
    image: "https://via.placeholder.com/200x200.png?text=Sao+Paulo",
  },
  {
    name: "Camisa Palmeiras 2025",
    price: 219.9,
    image: "https://via.placeholder.com/200x200.png?text=Palmeiras",
  },
];