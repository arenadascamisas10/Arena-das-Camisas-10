import React, { useState } from "react";
import Header from "./components/Header";
import ProductCard from "./components/ProductCard";
import Cart from "./components/Cart";
import products from "./products";

export default function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const removeFromCart = (index) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };

  return (
    <div>
      <Header cartCount={cart.length} />
      <main className="container">
        <h1>Arena das Camisas 10</h1>
        <div className="grid">
          {products.map((p, i) => (
            <ProductCard key={i} product={p} addToCart={addToCart} />
          ))}
        </div>
      </main>
      <Cart cart={cart} removeFromCart={removeFromCart} />
      <a
        href="https://wa.me/5599999999999"
        className="whatsapp"
        target="_blank"
        rel="noreferrer"
      >
        WhatsApp
      </a>
    </div>
  );
}