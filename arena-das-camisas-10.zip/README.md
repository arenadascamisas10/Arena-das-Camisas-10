# Arena das Camisas 10 👕

Loja virtual feita em **React + Vite** para venda de camisas de times.

## 🚀 Deploy

Clique no botão abaixo para publicar direto no Vercel:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/arenadascamisas10/arena-das-camisas-10)

## 📦 Como rodar local
```bash
npm install
npm run dev
```
Acesse: `http://localhost:5173`
